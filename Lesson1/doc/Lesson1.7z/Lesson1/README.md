# Lesson1

Este es el trabajo para la sesion de latencias de la universidad Carlos III de Madrid
    
## Resultados

Los resultados de todas las practicas se encuentran en /doc/resultados.txt